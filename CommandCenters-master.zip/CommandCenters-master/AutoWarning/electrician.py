# cac thu vien su dung
import numpy as np
import os
import cv2

def get_output_layers(net):
    layer_names = net.getLayerNames()

    output_layers = [layer_names[i[0] - 1] for i in net.getUnconnectedOutLayers()]

    return output_layers


def draw_prediction(img, class_id, confidence,classes,COLORS,x, y, x_plus_w, y_plus_h):
    label = str(classes[class_id])

    color = COLORS[class_id]

    cv2.rectangle(img, (x, y), (x_plus_w, y_plus_h), color, 2)

    cv2.putText(img, label, (x - 10, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)

def YoLo(image,classes_path,weights_path,config_path):
    image_temp = image
    net = cv2.dnn.readNet(weights_path, config_path)

    Width = image.shape[1]
    Height = image.shape[0]
    scale = 0.00392

    classes = None

    with open(classes_path, 'r') as f:
        classes = [line.strip() for line in f.readlines()]

    COLORS = np.random.uniform(0, 255, size=(len(classes), 3))

    blob = cv2.dnn.blobFromImage(image, scale, (416, 416), (0, 0, 0), True, crop=False)

    net.setInput(blob)

    outs = net.forward(get_output_layers(net))

    class_ids = []
    confidences = []
    boxes = []
    conf_threshold = 0.5
    nms_threshold = 0.4

    # Thực hiện xác định bằng HOG và SVM

    for out in outs:
        for detection in out:
            scores = detection[5:]
            class_id = np.argmax(scores)
            confidence = scores[class_id]
            if confidence > 0.5:
                center_x = int(detection[0] * Width)
                center_y = int(detection[1] * Height)
                w = int(detection[2] * Width)
                h = int(detection[3] * Height)
                x = center_x - w / 2
                y = center_y - h / 2
                class_ids.append(class_id)
                confidences.append(float(confidence))
                boxes.append([x, y, w, h])

    indices = cv2.dnn.NMSBoxes(boxes, confidences, conf_threshold, nms_threshold)

    cropped_images = []
    labels = []
    for i in indices:
        i = i[0]
        box = boxes[i]
        x = box[0]
        y = box[1]
        w = box[2]
        h = box[3]

        trai = round(x-w*0.1)
        phai = round(x+w*1.1)
        duoi = round(y-h*0.1)
        tren = round(y+h*1.1)
        if(trai<0): trai = 0
        if(phai>image.shape[1]): phai = image.shape[1]
        if(duoi<0): duoi = 0
        if(tren>image.shape[0]): tren = image.shape[0]

        cropped_images.append(image_temp[duoi:tren, trai:phai, :])
        labels.append(str(classes[class_ids[i]]))
        draw_prediction(image, class_ids[i], confidences[i], classes, COLORS, round(x), round(y), round(x + w), round(y + h))

    return image,cropped_images,labels



def list_test(test_path,classes_path,weights_path,config_path,save_file,cropped_save_file):
    list = os.listdir(test_path)
    for img in list:
        sv_file = os.path.join(save_file,img)
        image_path = os.path.join(test_path,img)
        image = cv2.imread(image_path)
        result,cropped_images,labels = YoLo(image,classes_path,weights_path,config_path)
        cv2.imwrite(sv_file,result)

        if (len(cropped_images) != 0):
            i = 1
            for croped_image in cropped_images:
                name = '%d.%s' % (i, img)
                crp_save_file = os.path.join(cropped_save_file, name)
                cv2.imwrite(crp_save_file, croped_image)
                i = i + 1

        print('detect xong %d anh'%(list.index(img)+1))


classes_path1 = 'yolov3_electrician.txt'
weights_path1 = 'yolov3_electrician.backup'

classes_path2 = 'yolov3_head.txt'
weights_path2 = 'yolov3_head.backup'

config_path = 'yolov3.cfg'

test_image_path = 'test.jpg'
test_image = cv2.imread(test_image_path)
result,cropped_images,labels = YoLo(test_image,classes_path1,weights_path1,config_path)
flag = 0
for i in range(len(cropped_images)):
    if(labels[i]=='person'): flag = 1
    else:
        cr_resultA,cr_cr_imgA,cr_labelsA = YoLo(cropped_images[i],classes_path2,weights_path2,config_path)
        if('warningA' in cr_labelsA): flag = 1

if(flag==1):print('SOS')
else: print('Normal')
